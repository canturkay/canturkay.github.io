<?php
error_reporting(0);

define('CACHE_ALIVE', 21600); // set in sec. One hour is 3600 sec

/***************************************************************************************
 * Twitter API settings
 **************************************************************************************/
define('TW_OAUTH_ACCESS_TOKEN', '839461704-APji4DuiSqcCB5L3Xgta1zSJ9xDoZbhXwCnveTjB');
define('TW_OAUTH_ACCESS_TOKEN_SECRET', 'vYHOriTdN94AGngL910KQWsUc8ZDY14DzzlyIWbD3l746');
define('TW_CONSUMER_KEY', '3rV5PJ2NlTn7itbaxabJezvGs');
define('TW_CONSUMER_SECRET', 'ufA5UlQpwZpTmoALJgHsZrHw2fHPdo9lHHsLOEggOamK5etyAW');
define('TW_TWITTER_UNAME', 'ItemBridge');
define('TW_COUNT_TWITTS', 10);
define('TW_CACHE_FILENAME', 'twitter.cache.txt');

/***************************************************************************************
 * Instagram API settings
 **************************************************************************************/
define('INST_API_KEY', '82ecb907e89f423da6b88d417a6ad762');
define('INST_API_SECRET', 'dfbf64982d054bf6bfd73c95e649e13e');
define('INST_USER_ID', '2209397545');
define('INST_COUNT', '10');
define('INST_CACHE_FILENAME', 'instagram.cache.txt');